package class.sample;


/**
 * @author Maciek
 * @version 1.0
 * @created 16-maj-2024 18:59:21
 */
public class Employee {

	private int id_number;
	private string Job_position;
	private string Name;
	private string Surname;
	public Employee m_Employee;
	public StationManager m_StationManager;

	public Employee(){

	}

	public void finalize() throws Throwable {

	}
	public void assignToStation(stationID: Integer)(){

	}

	public void getProfileDetails()(){

	}

	public void Name+updateProfile(newName: String, newSurname: String, newJobPosition: String)(){

	}
}//end Employee