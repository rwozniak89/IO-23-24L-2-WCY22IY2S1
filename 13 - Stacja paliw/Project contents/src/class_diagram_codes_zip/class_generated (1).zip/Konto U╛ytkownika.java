import class.sample.Vehicle;
import class.sample.Transaction;

/**
 * @author Maciek
 * @version 1.0
 * @created 16-maj-2024 18:59:24
 */
public class Konto U�ytkownika {

	private int customerID;
	private string emailAddress;
	private int password;
	private sting[] vehicleList;
	public Vehicle m_Vehicle;
	public Transaction m_Transaction;

	public Konto U�ytkownika(){

	}

	public void finalize() throws Throwable {

	}
	public void addVehicle(vehicle: Vehicle)(){

	}

	public boolean customerIDlogin(email: String, password: String)(){
		return false;
	}

	public void removeVehicle(vehicleID: Integer)(){

	}

	public void updateProfile(details: Map<String, String>)(){

	}
}//end Konto U�ytkownika