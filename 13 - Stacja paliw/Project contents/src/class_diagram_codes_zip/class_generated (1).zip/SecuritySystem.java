package class.sample;


/**
 * @author Maciek
 * @version 1.0
 * @created 16-maj-2024 18:59:24
 */
public class SecuritySystem {

	private int List<Alarm> alarms;
	private int List<Camera> surveillanceCameras;
	public Camera m_Camera;
	public Alarm m_Alarm;

	public SecuritySystem(){

	}

	public void finalize() throws Throwable {

	}
	public void activateAlarm(alarmID: Integer): void(){

	}

	public void deactivateAlarm(alarmID: Integer): void(){

	}

	public void reportIncident(incidentDetails: String): void(){

	}
}//end SecuritySystem