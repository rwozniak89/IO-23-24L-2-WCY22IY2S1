package class.sample;


/**
 * @author Maciek
 * @version 1.0
 * @created 16-maj-2024 18:59:20
 */
public class Camera {

	private int cameraID;
	private string location;
	private boolean recording;

	public Camera(){

	}

	public void finalize() throws Throwable {

	}
	public startTime: LocalDateTime, endTime: LocalDateTime etrieveFootage(){
		return null;
	}

	public void startRecording()(){

	}

	public void stopRecording()(){

	}
}//end Camera