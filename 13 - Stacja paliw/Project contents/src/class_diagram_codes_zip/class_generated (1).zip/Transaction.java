package class.sample;


/**
 * @author Maciek
 * @version 1.0
 * @created 16-maj-2024 18:59:25
 */
public class Transaction {

	private float amount;
	private int customer: CustomerAccount;
	private int dateTime: LocalDateTime;
	private string fuelType;
	private int transactionID;

	public Transaction(){

	}

	public void finalize() throws Throwable {

	}
	public void customer(){

	}

	public void transactionID(){

	}
}//end Transaction