package class.sample;


/**
 * @author Maciek
 * @version 1.0
 * @created 16-maj-2024 18:59:19
 */
public class Alarm {

	private boolean activated;
	private int alarmID;
	private string type;

	public Alarm(){

	}

	public void finalize() throws Throwable {

	}
	public void resetAlarm()(){

	}

	public void triggerAlarm()(){

	}

	public void updateAlarmSettings(settings: Map<String, String>)(){

	}
}//end Alarm