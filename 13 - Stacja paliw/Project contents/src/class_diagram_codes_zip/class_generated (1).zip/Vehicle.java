package class.sample;


/**
 * @author Maciek
 * @version 1.0
 * @created 16-maj-2024 18:59:26
 */
public class Vehicle {

	private string fuelPreference;
	private string licensePlate;
	private int owner: CustomerAccount;
	private int vehicleID;

	public Vehicle(){

	}

	public void finalize() throws Throwable {

	}
	public boolean authenticateLicensePlate(plate: String)(){
		return false;
	}

	public Map<String, String> getVehicleDetails()(){
		return null;
	}

	public void updateFuelPreference(newPreference: String)(){

	}
}//end Vehicle