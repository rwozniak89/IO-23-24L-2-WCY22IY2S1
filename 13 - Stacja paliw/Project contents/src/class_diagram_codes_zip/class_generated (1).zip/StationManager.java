package class.sample;


/**
 * @author Maciek
 * @version 1.0
 * @created 16-maj-2024 18:59:25
 */
public class StationManager extends InventoryManager {

	private FuelDispenser[] dispensers;
	private employees[] employees;
	private int stationID;

	public StationManager(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
	public void addDispenser(dispenser: FuelDispenser)(){

	}

	public string generateReport()(){
		return "";
	}

	public void removeDispenser(dispenserID: Integer)(){

	}

	public void scheduleMaintenance(maintenanceDetails: Map~String, String~)(){

	}
}//end StationManager