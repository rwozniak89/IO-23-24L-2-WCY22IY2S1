package class.sample;


/**
 * @author Maciek
 * @version 1.0
 * @created 16-maj-2024 18:59:22
 */
public class FuelDispenser extends StationManager {

	private int dispenserID;
	private string[] fuelTypeAvailable;
	private string status;

	public FuelDispenser(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
	public string checkStatus()(){
		return "";
	}

	public void dispenserID(){

	}

	public boolean reserveDispenser()(){
		return false;
	}

	public void updateFuelType(fuels: List~String~)(){

	}
}//end FuelDispenser