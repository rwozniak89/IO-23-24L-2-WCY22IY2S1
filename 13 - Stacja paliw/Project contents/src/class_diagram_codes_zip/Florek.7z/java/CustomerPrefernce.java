package java;

public class CustomerPrefernce {

	private int preferenceID;

	private CustomerAccount customer;

	private String preference;

	private LocalDateTime lastUpdated;

	private int frequency;

	public CustomerPreference(int preferenceID, CustomerAccount customer, String preference, LocalDateTime lastUpdated, int frequency) {

	}

	public void updatePreference(int preferenceID, String preference) {

	}

	public String getPreference(int preferenceID) {
		return null;
	}

	public void setPreference(int preferenceID, String preference) {

	}

	public boolean deletePreference(int preferenceID) {
		return false;
	}

	public void analyzePreferences(CustomerAccount customer) {

	}

}
