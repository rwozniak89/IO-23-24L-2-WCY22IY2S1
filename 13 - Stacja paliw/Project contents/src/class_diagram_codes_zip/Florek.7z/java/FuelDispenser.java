package java;

public class FuelDispenser {

	private int dispenserID;

	private String status;

	private String fuelType;

	private float fuelLevel;

	private String location;

	public boolean checkStatus(int dispenserID) {
		return false;
	}

	public boolean reserveDispenser(int dispenserID) {
		return false;
	}

	public boolean releaseDispenser(int dispenserID) {
		return false;
	}

	public boolean stopFueling(int dispenserID) {
		return false;
	}

	public boolean startFueling(int dispenserID) {
		return false;
	}

	public FuelDispenser(int dispenserID, String status, String fuelType, float fuelLevel, String location) {

	}

}
