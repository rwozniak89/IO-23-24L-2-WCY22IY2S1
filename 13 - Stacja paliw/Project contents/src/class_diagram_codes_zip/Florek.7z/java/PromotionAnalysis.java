package java;

public class PromotionAnalysis {

	private int analysisID;

	private int promotionID;

	private float effectiveness;

	private LocalDateTime date;

	private int reportID;

	public PromotionAnalysis(int analysisID, int promotionID, float effectiveness, LocalDateTime date, int reportID) {

	}

	public void analyzePromotion(int promotionID) {

	}

	public void generateReport(int analysisID) {

	}

	public String viewResults(int analysisID) {
		return null;
	}

	public void exportResults(int analysisID, String format) {

	}

	public boolean addComment(int analysisID, String comment) {
		return false;
	}

}
