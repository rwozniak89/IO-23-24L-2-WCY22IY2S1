package ClassDiagram;


/**
 * @author luke
 * @version 1.0
 * @created 26-maj-2024 20:16:13
 */
public class Klient extends Uzytkownik {

	private list historiaZakupow;
	private int id;
	private list informacjeOPlatnosciach;
	private list punktyLojalnosciowe;
	private list rabaty;
	private Recenzja recenzje;
	public Rabat m_Rabat;
	public PunktyLojalnosciowe m_PunktyLojalnosciowe;
	public Bilet m_Bilet;

	public Klient(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
	public void getHistoriaZakupow(){

	}

	public void getInformacjeOPlatnosciach(){

	}

	public void getPunktyLojalnosciowe(){

	}

	public void getRabaty(){

	}

	public void getRecenzje(){

	}
}//end Klient