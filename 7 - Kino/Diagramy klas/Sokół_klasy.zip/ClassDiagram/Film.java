package ClassDiagram;


/**
 * @author luke
 * @version 1.0
 * @created 26-maj-2024 20:16:13
 */
public class Film {

	private int czasTrwania;
	private data dataPremiery;
	private str gatunek;
	private int id;
	private list obsada;
	private double ocena;
	private str opis;
	private str plakat;
	private Recenzja recenzje;
	private str rezyser;
	private str trailer;
	private str tytul;
	public Recenzja m_Recenzja;
	public Seans m_Seans;
	public Pracownik m_Pracownik;

	public Film(){

	}

	public void finalize() throws Throwable {

	}
	public list getAktualneFilmy(){
		return null;
	}

	/**
	 * 
	 * @param ID
	 */
	public void getCzastrwania(int ID){

	}

	/**
	 * 
	 * @param ID
	 */
	public void getDataPremiery(int ID){

	}

	/**
	 * 
	 * @param ID
	 */
	public void getGatunek(int ID){

	}

	public void getID(){

	}

	/**
	 * 
	 * @param ID
	 */
	public void getObsada(int ID){

	}

	/**
	 * 
	 * @param ID
	 */
	public void getOcena(int ID){

	}

	/**
	 * 
	 * @param ID
	 */
	public void getOpis(int ID){

	}

	/**
	 * 
	 * @param ID
	 */
	public void getPlakat(int ID){

	}

	/**
	 * 
	 * @param ID
	 */
	public void getRecenzje(int ID){

	}

	/**
	 * 
	 * @param ID
	 */
	public void getRezyser(int ID){

	}

	/**
	 * 
	 * @param ID
	 */
	public void getSzczegolyFilmu(int ID){

	}

	/**
	 * 
	 * @param ID
	 */
	public void getTrailer(int ID){

	}

	/**
	 * 
	 * @param ID
	 */
	public void getTytul(int ID){

	}

	/**
	 * 
	 * @param id
	 */
	public void usunFilm(int id){

	}

	/**
	 * 
	 * @param czasTrwania
	 * @param dataPremiery
	 * @param gatunek
	 * @param recenzje
	 * @param obsada
	 * @param ocena
	 * @param opis
	 * @param plakat
	 * @param rezyser
	 * @param trailer
	 * @param tytul
	 */
	public void utworzFilm(int czasTrwania, date dataPremiery, str gatunek, Recenzja recenzje, list obsada, double ocena, str opis, str plakat, str rezyser, str trailer, str tytul){

	}

	public void wyswietlAktualneFilmy(){

	}
}//end Film