package ClassDiagram;


/**
 * @author luke
 * @version 1.0
 * @created 26-maj-2024 20:16:14
 */
public class Uzytkownik {

	private str adresEmail;
	private str haslo;
	private int id;
	private str imieNazwisko;
	private str numerTelefonu;

	public Uzytkownik(){

	}

	public void finalize() throws Throwable {

	}
	public void getEmailUzytkownika(){

	}

	public void getImieNazwiskoUzytkownika(){

	}

	public void getNumerTelefonu(){

	}

	public void setHaslo(){

	}

	public void setImieNazwisko(){

	}

	public void setNumerTelefonu(){

	}

	/**
	 * 
	 * @param id
	 */
	public void usunUzytkownika(int id){

	}

	/**
	 * 
	 * @param adresEmail
	 * @param haslo
	 * @param imieNazwisko
	 * @param numerTelefonu
	 */
	public void utworzUzytkownika(str adresEmail, str haslo, str imieNazwisko, str numerTelefonu){

	}
}//end Uzytkownik