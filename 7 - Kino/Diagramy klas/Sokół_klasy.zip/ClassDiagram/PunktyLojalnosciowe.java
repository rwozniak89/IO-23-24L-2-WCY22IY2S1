package ClassDiagram;


/**
 * @author luke
 * @version 1.0
 * @created 26-maj-2024 20:16:14
 */
public class PunktyLojalnosciowe {

	private int id;
	private int iloscPunktow;
	private Klient klient;

	public PunktyLojalnosciowe(){

	}

	public void finalize() throws Throwable {

	}
	/**
	 * 
	 * @param iloscPunktow
	 * @param klient
	 */
	public void dodajPunktyLojalnosciowe(int iloscPunktow, Klient klient){

	}

	public void getIloscPunktow(){

	}

	public void getKlient(){

	}

	/**
	 * 
	 * @param iloscPunktow
	 * @param klient
	 */
	public void usunPunktyLojalnosciowe(int iloscPunktow, Klient klient){

	}
}//end PunktyLojalnosciowe