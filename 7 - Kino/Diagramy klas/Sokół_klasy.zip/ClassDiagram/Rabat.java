package ClassDiagram;


/**
 * @author luke
 * @version 1.0
 * @created 26-maj-2024 20:16:14
 */
public class Rabat {

	private int id;
	private str nazwa;
	private double procentZnizki;

	public Rabat(){

	}

	public void finalize() throws Throwable {

	}
	public void getNazwa(){

	}

	public void getProcentZnizki(){

	}

	/**
	 * 
	 * @param id
	 */
	public void usunRabat(int id){

	}

	/**
	 * 
	 * @param nazwa
	 * @param procentZnizki
	 */
	public void utworzRabat(int nazwa, double procentZnizki){

	}
}//end Rabat