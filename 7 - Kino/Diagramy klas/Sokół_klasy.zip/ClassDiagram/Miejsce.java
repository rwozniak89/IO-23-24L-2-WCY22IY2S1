package ClassDiagram;


/**
 * @author luke
 * @version 1.0
 * @created 26-maj-2024 20:16:13
 */
public class Miejsce {

	private int id;
	private int numer;
	public Sala sala;

	public Miejsce(){

	}

	public void finalize() throws Throwable {

	}
	public void getID(){

	}

	public Sala getMiejscaNaSali(){
		return null;
	}

	public Sala getNumer(){
		return null;
	}

	public Sala getSala(){
		return null;
	}

	public Sala getStatusyMiejsc(){
		return null;
	}

	/**
	 * 
	 * @param id
	 */
	public Sala getSzczegolyMiejsca(int id){
		return null;
	}

	public void kupBilet(){

	}

	/**
	 * 
	 * @param id
	 */
	public Sala usunMiejsce(int id){
		return null;
	}

	/**
	 * 
	 * @param numer
	 * @param sala
	 */
	public Sala utworzMiejsce(int numer, Sala sala){
		return null;
	}

	public void wyswietlMiejscaNaSali(){

	}

	public void wyswietlStatusyMiejsc(){

	}
}//end Miejsce