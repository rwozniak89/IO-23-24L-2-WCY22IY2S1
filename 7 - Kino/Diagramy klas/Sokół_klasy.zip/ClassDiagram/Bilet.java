package ClassDiagram;


/**
 * @author luke
 * @version 1.0
 * @created 26-maj-2024 20:16:13
 */
public class Bilet {

	private double cena;
	private int id;
	private str kodQR;
	private Miejsce miejsce;
	private Seans seans;
	private Uzytkownik uzytkownik;

	public Bilet(){

	}

	public void finalize() throws Throwable {

	}
	public void getCena(){

	}

	public void getMiejsce(){

	}

	public void getQR(){

	}

	public void getSeans(){

	}

	public void getUzytkownik(){

	}
}//end Bilet