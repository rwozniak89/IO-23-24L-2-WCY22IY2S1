package ClassDiagram;


/**
 * @author luke
 * @version 1.0
 * @created 26-maj-2024 20:16:14
 */
public class Seans {

	private date czasRozpoczecia;
	public Film film;
	private int id;
	public Sala sala;
	public Bilet m_Bilet;
	public Sala m_Sala;

	public Seans(){

	}

	public void finalize() throws Throwable {

	}
	public void getCzasRozpoczecia(){

	}

	public list getDostepneSeanse(){
		return null;
	}

	public void getID(){

	}

	public void getSala(){

	}

	/**
	 * 
	 * @param id
	 */
	public void getSczegolySeansu(int id){

	}

	/**
	 * 
	 * @param id
	 */
	public void usunSeans(int id){

	}

	/**
	 * 
	 * @param czasRozpoczecia
	 * @param film
	 * @param sala
	 */
	public void utworzSeans(date czasRozpoczecia, Film film, Sala sala){

	}

	public void wyswietlDostepneSeanse(){

	}
}//end Seans