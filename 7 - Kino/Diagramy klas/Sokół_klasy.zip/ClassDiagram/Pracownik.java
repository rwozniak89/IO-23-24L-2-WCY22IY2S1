package ClassDiagram;


/**
 * @author luke
 * @version 1.0
 * @created 26-maj-2024 20:16:14
 */
public class Pracownik extends Uzytkownik {

	private str stanowisko;
	private list uprawnienia;
	public Rabat m_Rabat;
	public Seans m_Seans;
	public PunktyLojalnosciowe m_PunktyLojalnosciowe;

	public Pracownik(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}
	public void getStanowisko(){

	}

	public void getUprawnienia(){

	}
}//end Pracownik