package ClassDiagram;


/**
 * @author luke
 * @version 1.0
 * @created 26-maj-2024 20:16:14
 */
public class Recenzja {

	private Film film;
	private int id;
	private Klient klient;
	private double ocena;
	private str tresc;
	public Klient m_Klient;

	public Recenzja(){

	}

	public void finalize() throws Throwable {

	}
	public void getFilm(){

	}

	public void getOcena(){

	}

	public void getTresc(){

	}

	public void getUzytkownik(){

	}

	/**
	 * 
	 * @param id
	 */
	public void usunRecenzje(int id){

	}

	/**
	 * 
	 * @param film
	 * @param ocena
	 * @param tresc
	 * @param id
	 * @param klient
	 */
	public void utworzRecenzje(Film film, double ocena, str tresc, int id, Klient klient){

	}
}//end Recenzja