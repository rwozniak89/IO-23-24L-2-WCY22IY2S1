package ClassDiagram;


/**
 * @author luke
 * @version 1.0
 * @created 26-maj-2024 20:16:14
 */
public class Sala {

	private int id;
	private int liczbaMiejsc;
	private list miejsca;
	private str nazwa;
	private int pietro;
	public Miejsce m_Miejsce;
	public Pracownik m_Pracownik;

	public Sala(){

	}

	public void finalize() throws Throwable {

	}
	public Seans getDostepneSale(){
		return null;
	}

	public void getID(){

	}

	public void getLiczbaMiejsc(){

	}

	public void getMiejsce(){

	}

	public void getNazwa(){

	}

	public void getPietro(){

	}

	/**
	 * 
	 * @param id
	 */
	public void getSzczegolySali(int id){

	}

	/**
	 * 
	 * @param id
	 */
	public void usunSale(int id){

	}

	/**
	 * 
	 * @param liczbaMiejsc
	 * @param nazwa
	 * @param pietro
	 * @param miejsca
	 */
	public void utworzSale(int liczbaMiejsc, str nazwa, int pietro, list miejsca){

	}

	public void wyswietlDostepneSale(){

	}
}//end Sala